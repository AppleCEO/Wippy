{\rtf1\ansi\ansicpg949\cocoartf1038\cocoasubrtf360
{\fonttbl\f0\fnil\fcharset129 AppleGothic;}
{\colortbl;\red255\green255\blue255;}
\paperw11900\paperh16840\margl1440\margr1440\vieww13360\viewh8220\viewkind0
\pard\tx566\tx1133\tx1700\tx2267\tx2834\tx3401\tx3968\tx4535\tx5102\tx5669\tx6236\tx6803\ql\qnatural\pardirnatural

\f0\fs24 \cf0 \'b3\'aa\'b4\'ae\'b1\'db\'b2\'c3 3.02 \'bc\'b3\'c4\'a1\'b8\'a6 \'bd\'c3\'c0\'db\'c7\'d5\'b4\'cf\'b4\'d9.\
\
\'c0\'cc\'c1\'a6\'ba\'ce\'c5\'cd \'c4\'c4\'c7\'bb\'c5\'cd\'bf\'a1 \'b3\'aa\'b4\'ae\'b1\'db\'b2\'c3 \'bc\'b3\'c4\'a1\'b8\'a6 \'bd\'c3\'c0\'db\'c7\'d5\'b4\'cf\'b4\'d9.\
\
\'bc\'b3\'c4\'a1\'b8\'a6 \'bd\'c3\'c0\'db\'c7\'cf\'b1\'e2 \'c0\'fc \'b8\'f0\'b5\'e7 \'c7\'c1\'b7\'ce\'b1\'d7\'b7\'a5\'c0\'bb \'c1\'be\'b7\'e1\'c7\'cf\'bf\'a9 \'c1\'d6\'bd\'c3\'b1\'e2 \'b9\'d9\'b6\'f8\'b4\'cf\'b4\'d9.\
\'c6\'af\'c8\'f7 \'bb\'e7\'bf\'eb\'c1\'df\'c0\'ce \'b9\'ae\'bc\'ad\'c1\'a6\'c0\'db \'c7\'c1\'b7\'ce\'b1\'d7\'b7\'a5\'b0\'fa \'b1\'d7\'b7\'a1\'c7\'c8 \'c7\'c1\'b7\'ce\'b1\'d7\'b7\'a5\'c0\'bb \'b9\'dd\'b5\'e5\'bd\'c3 \
\'c1\'be\'b7\'e1\'c7\'d8\'be\'df \'bf\'f8\'c8\'b0\'c7\'d1 \'bc\'b3\'c4\'a1\'b0\'a1 \'b0\'a1\'b4\'c9\'c7\'d5\'b4\'cf\'b4\'d9. \'c0\'cc\'b4\'c2 \'bc\'b3\'c4\'a1 \'c0\'cc\'c8\'c4 MAC\'c0\'bb \
\'c1\'be\'b7\'e1\'c7\'cf\'c1\'f6 \'be\'ca\'b0\'ed\'bc\'ad\'b5\'b5 \'bd\'c3\'bd\'ba\'c5\'db \'c6\'c4\'c0\'cf\'c0\'bb \'bc\'f6\'c1\'a4\'c7\'d2 \'bc\'f6 \'c0\'d6\'b0\'d4 \'c7\'d8\'c1\'dd\'b4\'cf\'b4\'d9.\
\
\'b0\'e8\'bc\'d3\'c7\'cf\'bd\'c3\'b7\'c1\'b8\'e9 \'a1\'ae\'b0\'e8\'bc\'d3\'a1\'af \'b9\'f6\'c6\'b0\'c0\'bb \'b4\'ad\'b7\'af \'c1\'d6\'bc\'bc\'bf\'e4.}